//
//  ResultViewController.swift
//  prueba123
//
//  Created by user on 10/1/19.
//  Copyright © 2019 Adrian Cano. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var result: UILabel!
    
    let data = DataHolder.shared
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        result.text = "\(data.ahorroLed!) %"
    }
    

   
}
