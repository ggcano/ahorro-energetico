//
//  ViewController.swift
//  prueba123
//
//  Created by user on 10/1/19.
//  Copyright © 2019 Adrian Cano. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var metros = 100
    
    @IBOutlet weak var hab: UITextField!
    @IBOutlet weak var resultado: UILabel!
    @IBOutlet weak var btnMetros: UIButton!
    
    let data = DataHolder.shared

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func selectMetros(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: "Select Photo", message: "Select atleast one photo", preferredStyle: .actionSheet)
        
        let action1 = UIAlertAction(title: "<80", style: .default) { (action) in
            self.metros = 100
            self.btnMetros.setTitle("<80", for: .normal)
        }
        
        let action2 = UIAlertAction(title: "80-120", style: .default) { (action) in
            self.metros = 150
            self.btnMetros.setTitle("80-120", for: .normal)
        }
        
        let action3 = UIAlertAction(title: ">120", style: .default) { (action) in
            self.metros = 160
            self.btnMetros.setTitle(">120", for: .normal)
        }
        
        alertController.addAction(action1)
        alertController.addAction(action2)
        alertController.addAction(action3)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func click(_ sender: UIButton) {
        
        
        
        let result = calcularAhorro(numHabitaciones: Int(hab.text!) ?? 0, metros: metros)
        
        //resultado.text = "\(result)"
        
        data.ahorroLed = result
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ResultView") as! ResultViewController
        
        self.present(vc, animated: true, completion: nil)

        
    }

    
    func calcularAhorro(numHabitaciones: Int, metros: Int) -> Int {
        
        var sumaHalog = 0
        var sumaLed = 0
        
        if (metros <= 80) {
            sumaHalog = 242
            sumaLed = 14
        } else if (metros <= 120) {
            sumaHalog = 257
            sumaLed = 20
        }
        
        let hab = numHabitaciones + 4
        print("Hab. \(hab)")
        
        let res1 = (hab * 70) + sumaHalog
        print("Halog. \(res1) W.")
        
        let res2 = (hab * 8) + sumaLed
        print("Led \(res2) W.")
        
        let res3 = (res2 * 100) / res1
        print("Porce \(res3)")
        
        let res4 = 100 - res3
        print("Ahorro \(res4)")
        
        return res4
        
    }

}

