//
//  DataHolder.swift
//  prueba123
//
//  Created by user on 10/1/19.
//  Copyright © 2019 Adrian Cano. All rights reserved.
//

import Foundation

class DataHolder {
    
    static let shared = DataHolder()
    
    var ahorroLed: Int?
}
